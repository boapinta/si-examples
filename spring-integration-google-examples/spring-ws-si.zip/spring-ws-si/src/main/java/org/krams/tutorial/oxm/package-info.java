@javax.xml.bind.annotation.XmlSchema(namespace = "http://krams915.blogspot.com/ws/schema/oss", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.krams.tutorial.oxm;
