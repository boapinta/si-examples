package org.krams.tutorial.si;

import java.util.Map;

import org.apache.log4j.Logger;

/**
 *  Filters messages based on their keyword. If an item is invalid,
 *  it gets dropped from the normal process.
 *  <p>
 *  Valid keywords are SALES, INVENTORY, ORDER
 *  
 *  @author Krams at {@link http://krams915@blogspot.com}
 */
public class ProductFilter {

	protected static Logger logger = Logger.getLogger("integration");
	
	public Boolean filter(Map<?,?> map) {
		logger.debug(map.toString());
		
		String content = map.get("content").toString();
		String[] contentArray = content.split(";");
		
		if (contentArray[ApplicationConstants.TYPE_INDEX].equalsIgnoreCase(ApplicationConstants.TYPE_SALES)) {
        	return true;
        } 
		
		if (contentArray[ApplicationConstants.TYPE_INDEX].equalsIgnoreCase(ApplicationConstants.TYPE_INVENTORY)) {
			return true;
        } 
		
		if (contentArray[ApplicationConstants.TYPE_INDEX].equalsIgnoreCase(ApplicationConstants.TYPE_ORDER)) {
			return true;
        }  
		
		logger.debug("Invalid keyword found");
		return false;
	}
}
