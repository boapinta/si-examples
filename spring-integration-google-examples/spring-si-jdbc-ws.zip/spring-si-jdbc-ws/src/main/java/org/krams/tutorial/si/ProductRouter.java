package org.krams.tutorial.si;

import org.apache.log4j.Logger;

/**
 *  Routes messages based on their keyword. Invalid entries
 *  are routed to unknownChannel
 *  
 *  @author Krams at {@link http://krams915@blogspot.com}
 */
public class ProductRouter {

	protected static Logger logger = Logger.getLogger("integration");
	
	public String route(String[] contentArray) {
		
        if (contentArray[ApplicationConstants.TYPE_INDEX].equalsIgnoreCase(ApplicationConstants.TYPE_SALES)) {
    		logger.debug("Routing to salesChannel");
        	return "salesChannel";
        	
        } else if (contentArray[ApplicationConstants.TYPE_INDEX].equalsIgnoreCase(ApplicationConstants.TYPE_INVENTORY)) {
        	logger.debug("Routing to inventoryChannel");
        	return "inventoryChannel";
        	
        } else if (contentArray[ApplicationConstants.TYPE_INDEX].equalsIgnoreCase(ApplicationConstants.TYPE_ORDER)) {
        	logger.debug("Routing to orderChannel");
        	return "orderChannel";
        	
        } else  {
        	logger.debug("Routing to unknownChannel");
        	return "unknownChannel";
        } 
    }
}
